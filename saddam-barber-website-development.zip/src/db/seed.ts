import "dotenv/config";
import { db } from "./index";
import { services, barbers, testimonials } from "./schema";

async function seed() {
  await db.delete(testimonials);
  await db.delete(barbers);
  await db.delete(services);

  await db.insert(services).values([
    {
      nameAr: "قصة شعر",
      nameEn: "Haircut",
      descriptionAr: "قصة شعر عصرية تناسب وجهك مع غسيل شامل.",
      descriptionEn: "A modern haircut tailored to your face shape with a full wash.",
      price: "80.00",
      durationMinutes: 45,
      imageUrl: "/images/service-haircut.jpg",
      isActive: true,
    },
    {
      nameAr: "حلاقة الذقن",
      nameEn: "Beard Trim",
      descriptionAr: "تهذيب الذقن وتشكيلها باحترافية عالية.",
      descriptionEn: "Professional beard trimming and shaping.",
      price: "50.00",
      durationMinutes: 30,
      imageUrl: "/images/service-beard.jpg",
      isActive: true,
    },
    {
      nameAr: "قصة شعر + ذقن",
      nameEn: "Haircut + Beard",
      descriptionAr: "باقة كاملة للحصول على مظهر أنيق وجذاب.",
      descriptionEn: "A complete package for a sharp, attractive look.",
      price: "120.00",
      durationMinutes: 75,
      imageUrl: "/images/service-combo.jpg",
      isActive: true,
    },
    {
      nameAr: "تنظيف البشرة",
      nameEn: "Facial Cleansing",
      descriptionAr: "تنظيف عميق للبشرة بالمنتجات المناسبة.",
      descriptionEn: "Deep skin cleansing with suitable products.",
      price: "100.00",
      durationMinutes: 60,
      imageUrl: "/images/service-facial.jpg",
      isActive: true,
    },
    {
      nameAr: "صبغة شعر",
      nameEn: "Hair Coloring",
      descriptionAr: "ألوان عصرية بجودة عالية وثبات طويل.",
      descriptionEn: "Modern colors with high quality and long-lasting results.",
      price: "150.00",
      durationMinutes: 90,
      imageUrl: "/images/service-coloring.jpg",
      isActive: true,
    },
    {
      nameAr: "مساج الرأس",
      nameEn: "Head Massage",
      descriptionAr: "مساج استرخائي للرأس والرقبة.",
      descriptionEn: "Relaxing head and neck massage.",
      price: "60.00",
      durationMinutes: 30,
      imageUrl: "/images/service-massage.jpg",
      isActive: true,
    },
  ]);

  await db.insert(barbers).values([
    {
      nameAr: "صدّام",
      nameEn: "Saddam",
      roleAr: "مالك وكبير الحلاقين",
      roleEn: "Owner & Master Barber",
      bioAr: "خبرة أكثر من 15 عاماً في فن الحلاقة والعناية بالرجل.",
      bioEn: "Over 15 years of experience in the art of barbering and men's grooming.",
      imageUrl: "/images/barber-saddam.jpg",
      isActive: true,
    },
    {
      nameAr: "أحمد",
      nameEn: "Ahmed",
      roleAr: "حلاق محترف",
      roleEn: "Professional Barber",
      bioAr: "متخصص في القصات العصرية والتفاصيل الدقيقة.",
      bioEn: "Specialized in modern cuts and fine details.",
      imageUrl: "/images/barber-ahmed.jpg",
      isActive: true,
    },
    {
      nameAr: "محمد",
      nameEn: "Mohamed",
      roleAr: "حلاق ذقون",
      roleEn: "Beard Specialist",
      bioAr: "خبير في تهذيب وتشكيل الذقن بأحدث الطرق.",
      bioEn: "Expert in beard trimming and shaping with the latest techniques.",
      imageUrl: "/images/barber-mohamed.jpg",
      isActive: true,
    },
  ]);

  await db.insert(testimonials).values([
    {
      customerName: "عمر خالد",
      commentAr: "أفضل صالون حلاقة زرته على الإطلاق. الخدمة ممتازة والأجواء رائعة.",
      commentEn: "The best barbershop I've ever visited. Excellent service and great atmosphere.",
      rating: 5,
      isActive: true,
    },
    {
      customerName: "كريم محمود",
      commentAr: "صدّام يعرف شغله كويس جداً. القصة طلعت زي ما كنت عايزها بالظبط.",
      commentEn: "Saddam really knows his craft. The cut came out exactly as I wanted.",
      rating: 5,
      isActive: true,
    },
    {
      customerName: "يوسف سامي",
      commentAr: "نظافة واحترافية عالية. سعر مناسب جداً مقابل الجودة.",
      commentEn: "High cleanliness and professionalism. Very fair price for the quality.",
      rating: 4,
      isActive: true,
    },
  ]);

  console.log("Database seeded successfully");
  process.exit(0);
}

seed().catch((error) => {
  console.error("Seeding failed:", error);
  process.exit(1);
});
